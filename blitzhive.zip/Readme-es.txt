Instalaci�n manual del CMS Blitzhive
**Alpha Version

1# Descarga: http://blitzhive.com/download/

2# Edita el archivo config.php y cambia las variables $cnfHome='http://tusitio/';
  y $cnfAdm='blitz' por tu nombre futuro de administrador ejemplo: $cnfAdm='administrador'
   
3# Sube los archivos, dir�gete a http://tusitio/register.php y registra el usuario administrador    

4# Haz login con el nuevo usuario y dir�gete a admin.php.

5# Configura tu blitzhive, :)

6# Si quieres usarlo sin categor�as, simplemente renombra cat.php -> index.php

Reporta fallos en :http://blitzhive.com/Bugs/
A�ade mejoras: http://blitzhive.com/Mejoras/
