-=1.1.0.0 version=-
Bugs Fixed:
- Go to http://blitzhive.com/Bugs/
Upgrades:
- Go to http://blitzhive.com/Mejoras/

-=1.0.0.0 version=-
Bugs Fixed:
- Fixed a little bug in some blogs modes sites.
- Fixed bug of user not registered
- Fixed bug of annonymous anwser.
- Now delete and aprove answer works perfectly from admin.php
Upgrades:
- More readable code of w.php,user.php,cat.php and index.php
- Tags refill the input after upload
- More responsive css

Installation of CMS Blitzhive
**Alpha Version

1# Download: http://blitzhive.com/download/

2# Edit config.php and change the vars  $cnfHome='http://yoursite/' 
   and $cnfAdm='blitz' type your admin name example: $cnfAdm='admin'
   
3# Upload files, go to http://yoursite/register.php and add the new user admin   

4# Log in  using the new user 'admin' go to admin.php.

5# Set your CMS, :)

6# If you want use it with out categories, just rename cat.php -> index.php

English forum: http://blitzhive.net
Report bugs  :http://blitzhive.com/Bugs/
Add improvements: http://blitzhive.com/Mejoras/
